# Portable LaTeX source — Manuscript V1

This archive is self-contained for the venue-neutral manuscript source. It includes the manuscript `.tex`, cited `.bib`, all five referenced PNG figures, and all four referenced LaTeX table fragments.

## Recommended build

From the extracted archive root, with a standard TeX distribution providing `pdflatex`, `bibtex`, `natbib`, `graphicx`, `booktabs`, `array`, `amsmath`, `amssymb`, `geometry`, `microtype`, `url`, and `hyperref`:

```text
pdflatex manuscript_v1.tex
bibtex manuscript_v1
pdflatex manuscript_v1.tex
pdflatex manuscript_v1.tex
```

`latexmk -pdf manuscript_v1.tex` is an equivalent convenience command when `latexmk` is installed.

## Status of this package

The Markdown-to-LaTeX renderer and repository static verifiers succeeded in the preparation environment. No TeX engine (`pdflatex`, `xelatex`, `lualatex`, or `latexmk`) was installed there, so this archive was **not** compiled locally. The guide-review PDF supplied beside this archive is explicitly an alternative Microsoft Edge HTML/MathML rendering, not LaTeX output.

## Integrity and scope

The archive was extracted to a temporary directory after creation. Every `\input`, `\includegraphics`, and bibliography reference in `manuscript_v1.tex` was resolved within the extracted directory, and no dataset, model artifact, score trace, per-engine result, private log, or scientific workflow output is included.

The editable manuscript authority remains `MANUSCRIPT_V1.md` in the repository; this ZIP contains the synchronized venue-neutral LaTeX delivery source.
